class Tarea:
    def __init__(self):
        self.Id: str
        self.descripcion: str
        self.CantidadHoras: int
        self.status = 'A'